package localvolume

const (
	localVolumeUpdateFailed        = "LocalVolumeUpdateFailed"
	listingPersistentVolumesFailed = "ListingPersistentVolumeFailed"
	deletingStorageClassFailed     = "DeletingStorageClassFailed"
	localVolumeDeletionFailed      = "LocalVolumeDeletionFailed"
)
